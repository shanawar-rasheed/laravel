# SimpleAdminLTE
: is the AdminLTE template without example pages
# Complete AdminLTE: https://github.com/almasaeed2010/AdminLTE